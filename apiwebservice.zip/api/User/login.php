<?php
// incluir BD y archivos objeto
include_once '../config/database.php';
include_once '../objects/user.php';
 
// conexión a la BD
$database = new Database();
$db = $database->getConnection();
 
// preparar el objeto User
$user = new User($db);
// establecer la propiedad de identificación del usuario para ser editado
$user->username = isset($_GET['username']) ? $_GET['username'] : die();
$user->password = base64_encode(isset($_GET['password']) ? $_GET['password'] : die());
// leer los detalles del usuario para ser editado
$stmt = $user->login();
if($stmt->rowCount() > 0){
    // obtener fila recuperada
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // creando el arreglo
    $user_arr=array(
        "status" => true,
        "message" => "Successfully Login!",
        "id" => $row['id'],
        "username" => $row['username']
    );
}
else{
    $user_arr=array(
        "status" => false,
        "message" => "Invalid Username or Password!",
    );
}
// hacerlo en formato json
print_r(json_encode($user_arr));
?>