<?php
class Database{
 
    // Especificando los datos del servidor y BD
    private $host = "localhost";
    private $db_name = "apiservice";
    private $username = "root";
    private $password = "";
    public $conn;
 
    // Realizando la conexión
    public function getConnection(){
 
        $this->conn = null;
 
        try{
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8");
        }catch(PDOException $exception){
            echo "Connection error: " . $exception->getMessage();
        }
 
        return $this->conn;
    }
}
?>